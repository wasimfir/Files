package com.example.sahana.medisignup;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

/**
 * Created by Sahana on 6/22/2016.
 */
public class AdapterTips extends AppCompatActivity {

String[] category={"DIARRHOEA","COMMON COLD","GASTRIC","FEVER"};
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {super.onCreate(savedInstanceState);

        setContentView(R.layout.meditips);
        ArrayAdapter adapter=new ArrayAdapter<String>(this,R.layout.adapterlayout,category);
        ListView listView =(ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), DiarrLayout.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), CommoncoldLayout.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), GastroLayout.class);
                    startActivityForResult(myIntent, 0);
                }

                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), FeverLayout.class);
                    startActivityForResult(myIntent, 0);
                }

            }
        }
        );
}
}


