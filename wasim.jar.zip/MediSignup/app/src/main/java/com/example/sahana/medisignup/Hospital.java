package com.example.sahana.medisignup;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Sahana on 7/3/2016.
 */
public class Hospital extends Activity {
    String[] category = {"APPOLO HOSPITAL","INTERNATIONAL HOSPITAL","NEIGRIMS","LADY HARTINGE HOSPITAL","AIIMS",};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hospital);
        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.adapterlayout, category);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}


