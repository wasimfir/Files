package com.example.sahana.medisignup;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Sahana on 6/22/2016.
 */
public class DiarrLayout extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.diarrlayout);
    }
}
