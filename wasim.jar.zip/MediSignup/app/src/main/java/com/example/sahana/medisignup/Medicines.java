package com.example.sahana.medisignup;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Sahana on 6/30/2016.
 */
public class Medicines extends Activity {

    String[] category = {"PARACETAMOL", "DE-COLD","TYLENOL","ACETOMORPHEN", "ADVIL", "ASPIRIN", "DOCOSANOL","ZINTAC", "RANTADINE", "WOODWARDS GRIPE WATER", "LITACOLD", "SUMO", "COMBIFLAME"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.medicines);
        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.adapterlayout, category);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
    }
}
