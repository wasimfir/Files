package com.example.sahana.medisignup;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by Sahana on 6/21/2016.
 */
public class SignUp extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signupxml);
    }
}