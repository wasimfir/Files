package com.example.sahana.medisignup;

/**
 * Created by Sahana on 7/1/2016.
 */

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;


import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

/**
 * Created by Sahana on 6/30/2016.
 */
public class Doctors extends Activity {

    String[] category = {"Dr.Mujibur Rahman", "Dr.Arpan Kumar Chetiya", "Dr.Mintu Borgohain", "Dr.Taizuddin Ahmed", "Dr.Utpaljit Barman", "Dr.Biplav Agarwal", "Dr.Gautam Khaund", "Dr.Prashant Kumar"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doctorslist);
        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.adapterlayout, category);
        ListView listView = (ListView) findViewById(R.id.list);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (position == 0) {
                    Intent myIntent = new Intent(view.getContext(), DoctorFirst.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 1) {
                    Intent myIntent = new Intent(view.getContext(), DoctorSecond.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 2) {
                    Intent myIntent = new Intent(view.getContext(), DoctorThird.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 3) {
                    Intent myIntent = new Intent(view.getContext(), DoctorFourth.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 4) {
                    Intent myIntent = new Intent(view.getContext(), DoctorFifth.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 5) {
                    Intent myIntent = new Intent(view.getContext(), DoctorSixth.class);
                    startActivityForResult(myIntent, 0);
                }
                if (position == 6) {
                    Intent myIntent = new Intent(view.getContext(), DoctorSeventh.class);
                    startActivityForResult(myIntent, 0);
                }
            }
        });
    }}